close all
inverse = load('inverse.mat');
output = load('output.mat');

x = inverse.training(:, 1, 1:2);
n = inverse.training(:, 2, 1:2);
y = inverse.training(:, 3, 1:2);
% linear = inverse.training(:, 4, 1:2);
xn = x + n;

output = output.output;
% maxv = max(max(abs(output(:, 1:2))));
% output = output/100;
    

%% subplot 1
figure
hold on

min = inf;
point = 1/sqrt(2);
ind = 0;
for i = 1 : size(x, 1)
    min = inf;
    if(sum(abs(x(i, :) - [point, point])) < min)
        ind = 0;
        min = sum(abs(x(i, :) - [point, point]));
    end
    if(sum(abs(x(i, :) - [point, -point])) < min)
        ind = 1;
        min = sum(abs(x(i, :) - [point, -point]));
    end
    if(sum(abs(x(i, :) - [-point, point])) < min)
        ind = 2;
        min = sum(abs(x(i, :) - [-point, point]));
    end
    if(sum(abs(x(i, :) - [-point, -point])) < min)
        ind = 3;  
        min = sum(abs(x(i, :) - [-point, -point]));
    end
    
    switch ind
        case 0
            plot(xn(i, 1), xn(i, 2), 'gx')
            hold on
        case 1
            plot(xn(i, 1), xn(i, 2), 'bx')
            hold on
        case 2
            plot(xn(i, 1), xn(i, 2), 'rx')
            hold on
        case 3
            plot(xn(i, 1), xn(i, 2), 'yx')
            hold on
    end
end
axis([-2, 2, -2, 2])
xL = xlim;
yL = ylim;
line([0 0], yL, 'Color', 'black');
line(xL, [0 0], 'Color', 'black');
grid on
%% subplot 2
figure
min = inf;
point = 1/sqrt(2);
ind = 0;
for i = 1 : size(x, 1)
    min = inf;
    if(sum(abs(x(i, :) - [point, point])) < min)
        ind = 0;
        min = sum(abs(x(i, :) - [point, point]));
    end
    if(sum(abs(x(i, :) - [point, -point])) < min)
        ind = 1;
        min = sum(abs(x(i, :) - [point, -point]));
    end
    if(sum(abs(x(i, :) - [-point, point])) < min)
        ind = 2;
        min = sum(abs(x(i, :) - [-point, point]));
    end
    if(sum(abs(x(i, :) - [-point, -point])) < min)
        ind = 3;  
        min = sum(abs(x(i, :) - [-point, -point]));
    end
    
    switch ind
        case 0
            plot(y(i, 1), y(i, 2), 'gx')
            hold on
        case 1
            plot(y(i, 1), y(i, 2), 'bx')
            hold on
        case 2
            plot(y(i, 1), y(i, 2), 'rx')
            hold on
        case 3
            plot(y(i, 1), y(i, 2), 'yx')
            hold on
    end
end
% axis([-2, 2, -2, 2])
xL = xlim;
yL = ylim;
line([0 0], yL, 'Color', 'black');
line(xL, [0 0], 'Color', 'black');
grid on

%% sublot 3
figure
min = inf;
point = 1/sqrt(2);
ind = 0;
for i = 1 : size(x, 1)
    min = inf;
    if(sum(abs(x(i, :) - [point, point])) < min)
        ind = 0;
        min = sum(abs(x(i, :) - [point, point]));
    end
    if(sum(abs(x(i, :) - [point, -point])) < min)
        ind = 1;
        min = sum(abs(x(i, :) - [point, -point]));
    end
    if(sum(abs(x(i, :) - [-point, point])) < min)
        ind = 2;
        min = sum(abs(x(i, :) - [-point, point]));
    end
    if(sum(abs(x(i, :) - [-point, -point])) < min)
        ind = 3;  
        min = sum(abs(x(i, :) - [-point, -point]));
    end
    
    switch ind
        case 0
            plot(output(i, 1), output(i, 2), 'gx')
            hold on
        case 1
            plot(output(i, 1), output(i, 2), 'bx')
            hold on
        case 2
            plot(output(i, 1), output(i, 2), 'rx')
            hold on
        case 3
            plot(output(i, 1), output(i, 2), 'yx')
            hold on
    end
end
axis([-500, 500, -500, 500])
xL = xlim;
yL = ylim;
line([0 0], yL, 'Color', 'black');
line(xL, [0 0], 'Color', 'black');
grid on

%% sublot 4
% figure
% min = inf;
% point = 1/sqrt(2);
% ind = 0;
% for i = 1 : size(x, 1)
%     min = inf;
%     if(sum(abs(x(i, :) - [point, point])) < min)
%         ind = 0;
%         min = sum(abs(x(i, :) - [point, point]));
%     end
%     if(sum(abs(x(i, :) - [point, -point])) < min)
%         ind = 1;
%         min = sum(abs(x(i, :) - [point, -point]));
%     end
%     if(sum(abs(x(i, :) - [-point, point])) < min)
%         ind = 2;
%         min = sum(abs(x(i, :) - [-point, point]));
%     end
%     if(sum(abs(x(i, :) - [-point, -point])) < min)
%         ind = 3;  
%         min = sum(abs(x(i, :) - [-point, -point]));
%     end
%     
%     switch ind
%         case 0
%             plot(linear(i, 1), linear(i, 2), 'gx')
%             hold on
%         case 1
%             plot(linear(i, 1), linear(i, 2), 'bx')
%             hold on
%         case 2
%             plot(linear(i, 1), linear(i, 2), 'rx')
%             hold on
%         case 3
%             plot(linear(i, 1), linear(i, 2), 'yx')
%             hold on
%     end
% end
% % axis([-2, 2, -2, 2])
% xL = xlim;
% yL = ylim;
% line([0 0], yL, 'Color', 'black');
% line(xL, [0 0], 'Color', 'black');
% grid on